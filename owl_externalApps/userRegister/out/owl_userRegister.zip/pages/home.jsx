//#import Util.js

(function () {

    response.sendRedirect("login.jsx");
})();