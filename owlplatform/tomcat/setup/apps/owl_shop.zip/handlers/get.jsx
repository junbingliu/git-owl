//#import Util.js
//#import login.js
//#import session.js
//#import $owl_shop:services/modelService.jsx


var spec = {"id":"string(12),tab:01,disabled:true;店铺Id","name":"string(16),tab:02,searchable:true;店铺名称;","mobile":"string(16),inputType:mobile,tab:03;手机","logo":"imgfileId,tab:04;店铺logo","ownerName":"string(16),tab:09,searchable:true;店主","ownerUserId":"string(16),tab:09,searchable:true;店主Id","area":"tree,tab:11,dataSource:/owlApi/region/getArea.jsx; 地区","address":"string(24),tab:10;详细地址","type":"choice,values:1_商品销售/2_工业生产/3_服务销售,listSize:14,tab:06,listTab:09;店铺类型","bankInfo":{"#meta":{"fieldLabel":"银行资料","tab":"11"},"account":"string(19),inputType:number,tab:1101;账号","bank":"string(10),tab:1102;开户行","branch":"string(10),tab:1103;支行"},"registrationInfo":{"#meta":{"fieldLabel":"工商资料","tab":"12"},"address":"string(32),inputType:numberLetter,tab:1201;注册地址","registrationNumber":"string(19),tab:1202;工商登记号","businessRange":"string(128),tab:1203;营业范围"},"admins":[{"#meta":{"fieldLabel":"管理员","tab":"11","addMulti":{"linkId":"userId","from":"id","label":"选择用户...","dataSource":"/owlApi/user/search.jsx","fields":["id","loginId","realName","nickName"],"toFields":["userId","loginId","realName","nickName"],"fieldLabels":["id","loginId","真实姓名","昵称"],"fieldWidths":[100,120,120,120]}},"userId":"linkId,dataSource:/owlApi/user/search.jsx,unique:true,fields:id/realName/nickName,toFields:userId/realName/nickName,displayField:id,fieldsWidth:100/120/120,tab:13;用户Id","loginId":"string(16),disabled:true,inputType:numberLetter,tab:14;loginId","realName":"string(16),disabled:true,tab:14;姓名","nickName":"string(16),tab:15;昵称"}],"_t":"shop","#meta":{"rem":"店铺","parent":["subplatform"],"visitType":["platform"],"projectName":"店铺","export":[{"label":"导出完整","mainTitleFormat":{"background":"#474747","color":"#cccccc"},"subTitleFormat":{"background":"#777777","color":"#ffffff"},"subRecordFormat":{"background":"#ffffff","color":"#000000"},"mainRecordFormat":{"background":"#555555","color":"#FFFFFF"},"key":"completeDoc","fields":["*"]}]}};

var backendUserId = LoginService.getBackEndLoginUserId();
var visitType = SessionService.getSessionValue( "visitType", request );
if (visitType) {
  visitType = JSON.parse( visitType );
}

var shopId = visitType.shop;
var warehouseId = visitType.warehouse;
m=shopId;
//为了显示数据，临时加上这个判断，现在很多数据都搜索不出来
if(!m){
  m = SessionService.getSessionValue("_loginMerId",request);
}
//判断是subplatform,还是shop,还是platform
var params = JSON.parse($body);
var id = params.id;

var obj = owl_shopService.get(id);
var ret = {
  state:'ok',
  obj:obj
}
out.print(JSON.stringify(ret));