//#import Util.js
//#import login.js
//#import base64.js
//#import HttpUtil.js
//#import session.js
//#import $owl_shop:services/modelService.jsx
function trim(s){
  if(s){
    return s.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '');
  }
  return ""
}
var spec = {"id":"string(12),tab:01,disabled:true;店铺Id","name":"string(16),tab:02,searchable:true;店铺名称;","mobile":"string(16),inputType:mobile,tab:03;手机","logo":"imgfileId,tab:04;店铺logo","ownerName":"string(16),tab:09,searchable:true;店主","ownerUserId":"string(16),tab:09,searchable:true;店主Id","area":"tree,tab:11,dataSource:/owlApi/region/getArea.jsx; 地区","address":"string(24),tab:10;详细地址","type":"choice,values:1_商品销售/2_工业生产/3_服务销售,listSize:14,tab:06,listTab:09;店铺类型","bankInfo":{"#meta":{"fieldLabel":"银行资料","tab":"11"},"account":"string(19),inputType:number,tab:1101;账号","bank":"string(10),tab:1102;开户行","branch":"string(10),tab:1103;支行"},"registrationInfo":{"#meta":{"fieldLabel":"工商资料","tab":"12"},"address":"string(32),inputType:numberLetter,tab:1201;注册地址","registrationNumber":"string(19),tab:1202;工商登记号","businessRange":"string(128),tab:1203;营业范围"},"admins":[{"#meta":{"fieldLabel":"管理员","tab":"11","addMulti":{"linkId":"userId","from":"id","label":"选择用户...","dataSource":"/owlApi/user/search.jsx","fields":["id","loginId","realName","nickName"],"toFields":["userId","loginId","realName","nickName"],"fieldLabels":["id","loginId","真实姓名","昵称"],"fieldWidths":[100,120,120,120]}},"userId":"linkId,dataSource:/owlApi/user/search.jsx,unique:true,fields:id/realName/nickName,toFields:userId/realName/nickName,displayField:id,fieldsWidth:100/120/120,tab:13;用户Id","loginId":"string(16),disabled:true,inputType:numberLetter,tab:14;loginId","realName":"string(16),disabled:true,tab:14;姓名","nickName":"string(16),tab:15;昵称"}],"_t":"shop","#meta":{"rem":"店铺","parent":["subplatform"],"visitType":["platform"],"projectName":"店铺","export":[{"label":"导出完整","mainTitleFormat":{"background":"#474747","color":"#cccccc"},"subTitleFormat":{"background":"#777777","color":"#ffffff"},"subRecordFormat":{"background":"#ffffff","color":"#000000"},"mainRecordFormat":{"background":"#555555","color":"#FFFFFF"},"key":"completeDoc","fields":["*"]}]}};

var backendUserId = LoginService.getBackEndLoginUserId();

var visitType = SessionService.getSessionValue( "visitType", request );
if (visitType) {
  visitType = JSON.parse( visitType );
}

var shopId = visitType.shop;
var warehouseId = visitType.warehouse;
m = shopId;

//判断是subplatform,还是shop,还是platform
var params = JSON.parse($body);
var searchArgs = params.searchArgs;
var keyword = searchArgs.keyword;
var pageSize = params.pageSize;
var page = params.page;
if(!page){
  page = 1;
}
if(!pageSize){
  pageSize=15;
}
pageSize = Number(pageSize);
var from = page * pageSize-pageSize;

function getKeywordQuery(){
  if(keyword && trim(keyword).length>0){
    return "\"" + trim(keyword) + "\""
  }
  else{
    return "*"
  }
}

function getFilters(){
  delete searchArgs.keyword;
  var filters = [];
  for(var k in searchArgs){
    var v = searchArgs[k];
    if(typeof(v)=='object' && Array.isArray(v)){
      var range={}
      range[k] = {
        'gte':v[0],
        'lte':v[1]
      }
      filters.push({range:range});
    }
    else{
      var term = {};
      if(v){
          term[k+".keyword"] = trim('' + v)
          filters.push({term:term})
      }

    }

  }
  return filters;
}

var filters = getFilters();

if(m !== '0'){
    filters = filters.concat([
        {"term": { "_m.keyword": m }},
        {"term":{"_t":spec["_t"]}}
    ]);
}
else{
  //如果m === '0'，代表是平台
    filters = filters.concat([
        {"term":{"_t":spec["_t"]}}
    ]);
}


var query = {
  "query": {
    "bool": {
      "must": {
        "query_string": {
          "query":getKeywordQuery()
        }
      },
      "must_not": {
        "match": {
          "del": "T"
        }
      },
      "filter": filters
    }
  },
  "from" : from, "size" : pageSize,
  sort:[{_createTime:{order:"desc"}}]
}

var elasticSearchUrl = $.getEnv( "elasticSearchUrl" );

var headers = { "Content-Type": "application/json;charset=utf-8" };
var elasticSearchUser = $.getEnv("elasticSearchUser");
var elasticSearchPass = $.getEnv("elasticSearchPass");
if(elasticSearchUser && elasticSearchPass){
  var auth =Base64.encode(elasticSearchUser + ":" + elasticSearchPass);
  var basicAuth = "Basic " + auth;
  headers["Authorization"] = basicAuth;
}
var searchUrl = elasticSearchUrl+"/owl_shop/_search";

var sndTxt = JSON.stringify(query);
$.log(sndTxt);


var s = HttpUtils.postRaw( searchUrl, sndTxt, headers);
var result = JSON.parse(s);

var hits = result.hits.hits;
var total = result.hits.total;

var objs = hits.map(function(hit){return hit._source});

//这里重新从pigeon取了一次数据，做了删除的判断
// var ids = hits.map(function(hit){return hit._source.id});
// var list = owl_shopService.getObjects(ids);
// var objs  = list.filter(function(value){
//   return value.del != "T";
// });
var ret = {
  state:'ok',
  list:objs,
  total:total
}
out.print(JSON.stringify(ret));


