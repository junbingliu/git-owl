//#import $owl_shop:services/modelService.jsx
//#import moment.min.js
//#import excel.js

var formSpecs = {"meta":{"rem":"店铺","parent":["subplatform"],"visitType":["platform"],"projectName":"店铺","export":[{"label":"导出完整","mainTitleFormat":{"background":"#474747","color":"#cccccc"},"subTitleFormat":{"background":"#777777","color":"#ffffff"},"subRecordFormat":{"background":"#ffffff","color":"#000000"},"mainRecordFormat":{"background":"#555555","color":"#FFFFFF"},"key":"completeDoc","fields":["*"]}]},"_ft":"subForm","fields":[{"fieldType":"string","fieldSize":12,"tab":"01","disabled":"true","fieldLabel":"店铺Id","_ft":"field","key":"id","origKey":"id"},{"fieldType":"string","fieldSize":16,"tab":"02","searchable":"true","fieldLabel":"店铺名称","_ft":"field","key":"name","origKey":"name"},{"fieldType":"string","fieldSize":16,"inputType":"mobile","tab":"03","fieldLabel":"手机","_ft":"field","key":"mobile","origKey":"mobile"},{"fieldType":"imgfileId","tab":"04","fieldLabel":"店铺logo","_ft":"field","key":"logo","origKey":"logo"},{"fieldType":"string","fieldSize":16,"tab":"09","searchable":"true","fieldLabel":"店主","_ft":"field","key":"ownerName","origKey":"ownerName"},{"fieldType":"string","fieldSize":16,"tab":"09","searchable":"true","fieldLabel":"店主Id","_ft":"field","key":"ownerUserId","origKey":"ownerUserId"},{"fieldType":"tree","tab":"11","dataSource":"/owlApi/region/getArea.jsx","fieldLabel":" 地区","_ft":"field","key":"area","origKey":"area"},{"fieldType":"string","fieldSize":24,"tab":"10","fieldLabel":"详细地址","_ft":"field","key":"address","origKey":"address"},{"fieldType":"choice","values":"1_商品销售/2_工业生产/3_服务销售","listSize":"14","tab":"06","listTab":"09","options":[["1","商品销售"],["2","工业生产"],["3","服务销售"]],"fieldLabel":"店铺类型","_ft":"field","key":"type","origKey":"type"},{"meta":{"fieldLabel":"银行资料","tab":"11"},"_ft":"subform","fields":[{"fieldType":"string","fieldSize":19,"inputType":"number","tab":"1101","fieldLabel":"账号","_ft":"field","key":"bankInfo.account","origKey":"account"},{"fieldType":"string","fieldSize":10,"tab":"1102","fieldLabel":"开户行","_ft":"field","key":"bankInfo.bank","origKey":"bank"},{"fieldType":"string","fieldSize":10,"tab":"1103","fieldLabel":"支行","_ft":"field","key":"bankInfo.branch","origKey":"branch"}],"tab":"11","fieldLabel":"银行资料","key":"bankInfo","origKey":"bankInfo"},{"meta":{"fieldLabel":"工商资料","tab":"12"},"_ft":"subform","fields":[{"fieldType":"string","fieldSize":32,"inputType":"numberLetter","tab":"1201","fieldLabel":"注册地址","_ft":"field","key":"registrationInfo.address","origKey":"address"},{"fieldType":"string","fieldSize":19,"tab":"1202","fieldLabel":"工商登记号","_ft":"field","key":"registrationInfo.registrationNumber","origKey":"registrationNumber"},{"fieldType":"string","fieldSize":128,"tab":"1203","fieldLabel":"营业范围","_ft":"field","key":"registrationInfo.businessRange","origKey":"businessRange"}],"tab":"12","fieldLabel":"工商资料","key":"registrationInfo","origKey":"registrationInfo"},{"meta":{"fieldLabel":"管理员","tab":"11","addMulti":{"linkId":"userId","from":"id","label":"选择用户...","dataSource":"/owlApi/user/search.jsx","fields":["id","loginId","realName","nickName"],"toFields":["userId","loginId","realName","nickName"],"fieldLabels":["id","loginId","真实姓名","昵称"],"fieldWidths":[100,120,120,120]}},"_ft":"array","fields":[{"fieldType":"linkId","dataSource":"/owlApi/user/search.jsx","unique":"true","fields":"id/realName/nickName","toFields":"userId/realName/nickName","displayField":"id","fieldsWidth":"100/120/120","tab":"13","fieldLabel":"用户Id","_ft":"field","key":"admins.userId","origKey":"userId"},{"fieldType":"string","fieldSize":16,"disabled":"true","inputType":"numberLetter","tab":"14","fieldLabel":"loginId","_ft":"field","key":"admins.loginId","origKey":"loginId"},{"fieldType":"string","fieldSize":16,"disabled":"true","tab":"14","fieldLabel":"姓名","_ft":"field","key":"admins.realName","origKey":"realName"},{"fieldType":"string","fieldSize":16,"tab":"15","fieldLabel":"昵称","_ft":"field","key":"admins.nickName","origKey":"nickName"}],"tab":"11","fieldLabel":"管理员","key":"admins","origKey":"admins"}],"tab":"99","fieldLabel":"请完善资料"};

function tranverseFields(formSpec, callback, ctx){
  formSpec.fields.forEach( function(field){
    if (field[ '_ft' ] == 'field') {
      callback( field, ctx );
    }
    else if (field[ '_ft' ] == 'subform') {
      var context = { parentField: field }
      tranverseFields( field, callback, context );
    }
    else if (field[ '_ft' ] == 'array') {
      var context = { parentField: field }
      tranverseFields( field, callback, context )
    }
  } );
}

function normalizeValue(value,spec){
  if(value == null){
    return null;
  }
  switch (spec.fieldType){
    case 'string':
      return 's'+value;
    case 'number':
      return 'n' + value;
    case 'date':
      return 'd'+ moment(value).toDate().getTime();
    case 'choice':
      for(var i=0; i<spec.options.length; i++){
        var option = spec.options[i];
        if(option[0]==value){
          return 's'+option[1];
        }
      }
      return 's'+value;
    default:
      return "s"+value;
  }
}

function getExportDoc(obj){
  tranverseFields(formSpecs,function(f,ctx){
    if (ctx.parentField && ctx.parentField._ft == 'array') {
      var items = owl_shopService.getValue( ctx.parentField.key, obj )
      if(items){
        for(var i=0; i<items.length; i++){
          var item = items[i];
          var value = item[f.origKey];
          value = normalizeValue(value,f);
          item[f.origKey] = value;
        }
      }
    }
    else{
      var value = owl_shopService.getValue( f.key, obj );
      value = normalizeValue(value,f);
      owl_shopService.setValue(f.key,value,obj);
    }
  },{});
  return obj;
}


(function(){
  var doc = owl_shopService.get(id);
  var exportDoc = getExportDoc(doc);
  var templateExcelUrl = "@{owl_shop.xlsx}@";
  var  fileId = Excel.generateExcelFromTemplate( templateExcelUrl, exportDoc );

  $.log("exportDoc Success, fileId=" + fileId  + ",taskInfoId=" + taskInfoId);
  var  taskInfo = owl_shopService.getExportTaskInfo( taskInfoId );
  taskInfo.processState = "success";
  taskInfo.percent = 100;
  taskInfo.fileId = fileId;
  taskInfo.total = 1;
  taskInfo.lastTime = new Date().getTime();
  taskInfo.msg = "生成Excel文件成功";
  owl_shopService.updateExportTaskInfo(taskInfoId, taskInfo );
  $.log("update taskInfo Success, fileId=" + fileId  + ",taskInfoId=" + taskInfoId);
})();

