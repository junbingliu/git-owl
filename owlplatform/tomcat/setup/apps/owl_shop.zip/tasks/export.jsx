//#import $owl_shop:services/modelService.jsx
//#import moment.min.js
//#import excel.js


var formSpecs = {"meta":{"rem":"店铺","parent":["subplatform"],"visitType":["platform"],"projectName":"店铺","export":[{"label":"导出完整","mainTitleFormat":{"background":"#474747","color":"#cccccc"},"subTitleFormat":{"background":"#777777","color":"#ffffff"},"subRecordFormat":{"background":"#ffffff","color":"#000000"},"mainRecordFormat":{"background":"#555555","color":"#FFFFFF"},"key":"completeDoc","fields":["*"]}]},"_ft":"subForm","fields":[{"fieldType":"string","fieldSize":12,"tab":"01","disabled":"true","fieldLabel":"店铺Id","_ft":"field","key":"id","origKey":"id"},{"fieldType":"string","fieldSize":16,"tab":"02","searchable":"true","fieldLabel":"店铺名称","_ft":"field","key":"name","origKey":"name"},{"fieldType":"string","fieldSize":16,"inputType":"mobile","tab":"03","fieldLabel":"手机","_ft":"field","key":"mobile","origKey":"mobile"},{"fieldType":"imgfileId","tab":"04","fieldLabel":"店铺logo","_ft":"field","key":"logo","origKey":"logo"},{"fieldType":"string","fieldSize":16,"tab":"09","searchable":"true","fieldLabel":"店主","_ft":"field","key":"ownerName","origKey":"ownerName"},{"fieldType":"string","fieldSize":16,"tab":"09","searchable":"true","fieldLabel":"店主Id","_ft":"field","key":"ownerUserId","origKey":"ownerUserId"},{"fieldType":"tree","tab":"11","dataSource":"/owlApi/region/getArea.jsx","fieldLabel":" 地区","_ft":"field","key":"area","origKey":"area"},{"fieldType":"string","fieldSize":24,"tab":"10","fieldLabel":"详细地址","_ft":"field","key":"address","origKey":"address"},{"fieldType":"choice","values":"1_商品销售/2_工业生产/3_服务销售","listSize":"14","tab":"06","listTab":"09","options":[["1","商品销售"],["2","工业生产"],["3","服务销售"]],"fieldLabel":"店铺类型","_ft":"field","key":"type","origKey":"type"},{"meta":{"fieldLabel":"银行资料","tab":"11"},"_ft":"subform","fields":[{"fieldType":"string","fieldSize":19,"inputType":"number","tab":"1101","fieldLabel":"账号","_ft":"field","key":"bankInfo.account","origKey":"account"},{"fieldType":"string","fieldSize":10,"tab":"1102","fieldLabel":"开户行","_ft":"field","key":"bankInfo.bank","origKey":"bank"},{"fieldType":"string","fieldSize":10,"tab":"1103","fieldLabel":"支行","_ft":"field","key":"bankInfo.branch","origKey":"branch"}],"tab":"11","fieldLabel":"银行资料","key":"bankInfo","origKey":"bankInfo"},{"meta":{"fieldLabel":"工商资料","tab":"12"},"_ft":"subform","fields":[{"fieldType":"string","fieldSize":32,"inputType":"numberLetter","tab":"1201","fieldLabel":"注册地址","_ft":"field","key":"registrationInfo.address","origKey":"address"},{"fieldType":"string","fieldSize":19,"tab":"1202","fieldLabel":"工商登记号","_ft":"field","key":"registrationInfo.registrationNumber","origKey":"registrationNumber"},{"fieldType":"string","fieldSize":128,"tab":"1203","fieldLabel":"营业范围","_ft":"field","key":"registrationInfo.businessRange","origKey":"businessRange"}],"tab":"12","fieldLabel":"工商资料","key":"registrationInfo","origKey":"registrationInfo"},{"meta":{"fieldLabel":"管理员","tab":"11","addMulti":{"linkId":"userId","from":"id","label":"选择用户...","dataSource":"/owlApi/user/search.jsx","fields":["id","loginId","realName","nickName"],"toFields":["userId","loginId","realName","nickName"],"fieldLabels":["id","loginId","真实姓名","昵称"],"fieldWidths":[100,120,120,120]}},"_ft":"array","fields":[{"fieldType":"linkId","dataSource":"/owlApi/user/search.jsx","unique":"true","fields":"id/realName/nickName","toFields":"userId/realName/nickName","displayField":"id","fieldsWidth":"100/120/120","tab":"13","fieldLabel":"用户Id","_ft":"field","key":"admins.userId","origKey":"userId"},{"fieldType":"string","fieldSize":16,"disabled":"true","inputType":"numberLetter","tab":"14","fieldLabel":"loginId","_ft":"field","key":"admins.loginId","origKey":"loginId"},{"fieldType":"string","fieldSize":16,"disabled":"true","tab":"14","fieldLabel":"姓名","_ft":"field","key":"admins.realName","origKey":"realName"},{"fieldType":"string","fieldSize":16,"tab":"15","fieldLabel":"昵称","_ft":"field","key":"admins.nickName","origKey":"nickName"}],"tab":"11","fieldLabel":"管理员","key":"admins","origKey":"admins"}],"tab":"99","fieldLabel":"请完善资料"};

function getFieldByKey(fullKey){
  var keys = fullKey.split(".");
  var curField = formSpecs;
  for(var i=0; i<keys.length; i++){
    if(curField._ft=='field'){
      if(curField.key == fullKey){
        return curField;
      }
      else{
        return null;
      }
    }
    else{
      var key = keys[i];
      var fields = curField.fields;
      curField == null;
      for(var j=0; j<fields.length; j++){
        var f = fields[j];
        if(f.origKey == key){
          curField = f;
          break;
        }
      }
      if(curField==null){
        return null;
      }
    }
  }
  return curField;
}


function normalizeValue(value,spec){
  if(value == null){
    return null;
  }
  switch (spec.fieldType){
    case 'string':
      return 's'+value;
    case 'number':
      return 'n' + value;
    case 'date':
      return 'd'+ moment(value).toDate().getTime();
    case 'choice':
      for(var i=0; i<spec.options.length; i++){
        var option = spec.options[i];
        if(option[0]==value){
          return 's'+option[1];
        }
      }
      return 's'+value;
    default:
      return "s"+value;
  }
}

function tranverseFields(formSpec, callback, ctx){
  formSpec.fields.forEach( function(field){
    if (field[ '_ft' ] == 'field') {
      callback( field, ctx );
    }
    else if (field[ '_ft' ] == 'subform') {
      var context = { parentField: field }
      tranverseFields( field, callback, context );
    }
    else if (field[ '_ft' ] == 'array') {
      var context = { parentField: field }
      tranverseFields( field, callback, context )
    }
  } );
}

function getMainAndSubFields(exConfig){
  var mainFields = [];
  var subFields = [];
  if (exConfig.fields == "*") {
    tranverseFields(formSpecs,function(field,ctx){
      if (ctx.parentField && ctx.parentField._ft == 'array') {
        //nothing
      }
      else {
        mainFields.push( field );
      }
    },{})
  }
  else{
    for(var i=0; i<exConfig.fields.length; i++){
      var fieldKey = exConfig.fields[i];
      var field = getFieldByKey(fieldKey);
      if(field){
        mainFields.push(field);
      }
    }
  }

  if(exConfig && exConfig.items && exConfig.items.name){
    if(exConfig.items.itemFields=='*'){
      //找到items.name对应的field
      var f = getFieldByKey(exConfig.items.name);
      f.fields.forEach(function(spec){
        if(spec._ft=='field'){
          subFields.push(spec);
        }
      });
    }
    else{
      for(var i=0; i<exConfig.items.itemFields.length; i++){
        var itemField = exConfig.items.itemFields[i];
        var fieldKey = "";
        if(itemField.indexOf("$parent.")==0){
          fieldKey = itemField.substring(8);
          var field = getFieldByKey(fieldKey);
          if(field){
            field.isItemField = false;
            subFields.push(field);
          }
          else{
            $.log("panic!!!!-------------------------++++++++++++++" + fieldKey);
          }

        }
        else{
          fieldKey =  exConfig.items.name + "." + itemField;
          var field = getFieldByKey(fieldKey);
          if(field){
            field.isItemField = true;
            subFields.push(field);
          }
          else{
            $.log("panic!!!!-------------------------++++++++++++++" + fieldKey);
          }

        }


      }
    }
  }
  return [mainFields,subFields];
}



(function(){
    var spec = {"id":"string(12),tab:01,disabled:true;店铺Id","name":"string(16),tab:02,searchable:true;店铺名称;","mobile":"string(16),inputType:mobile,tab:03;手机","logo":"imgfileId,tab:04;店铺logo","ownerName":"string(16),tab:09,searchable:true;店主","ownerUserId":"string(16),tab:09,searchable:true;店主Id","area":"tree,tab:11,dataSource:/owlApi/region/getArea.jsx; 地区","address":"string(24),tab:10;详细地址","type":"choice,values:1_商品销售/2_工业生产/3_服务销售,listSize:14,tab:06,listTab:09;店铺类型","bankInfo":{"#meta":{"fieldLabel":"银行资料","tab":"11"},"account":"string(19),inputType:number,tab:1101;账号","bank":"string(10),tab:1102;开户行","branch":"string(10),tab:1103;支行"},"registrationInfo":{"#meta":{"fieldLabel":"工商资料","tab":"12"},"address":"string(32),inputType:numberLetter,tab:1201;注册地址","registrationNumber":"string(19),tab:1202;工商登记号","businessRange":"string(128),tab:1203;营业范围"},"admins":[{"#meta":{"fieldLabel":"管理员","tab":"11","addMulti":{"linkId":"userId","from":"id","label":"选择用户...","dataSource":"/owlApi/user/search.jsx","fields":["id","loginId","realName","nickName"],"toFields":["userId","loginId","realName","nickName"],"fieldLabels":["id","loginId","真实姓名","昵称"],"fieldWidths":[100,120,120,120]}},"userId":"linkId,dataSource:/owlApi/user/search.jsx,unique:true,fields:id/realName/nickName,toFields:userId/realName/nickName,displayField:id,fieldsWidth:100/120/120,tab:13;用户Id","loginId":"string(16),disabled:true,inputType:numberLetter,tab:14;loginId","realName":"string(16),disabled:true,tab:14;姓名","nickName":"string(16),tab:15;昵称"}],"_t":"shop","#meta":{"rem":"店铺","parent":["subplatform"],"visitType":["platform"],"projectName":"店铺","export":[{"label":"导出完整","mainTitleFormat":{"background":"#474747","color":"#cccccc"},"subTitleFormat":{"background":"#777777","color":"#ffffff"},"subRecordFormat":{"background":"#ffffff","color":"#000000"},"mainRecordFormat":{"background":"#555555","color":"#FFFFFF"},"key":"completeDoc","fields":["*"]}]}};
    var q = JSON.parse(query);
    var ctx = JSON.parse(env);
    var exportKey = ctx.exportKey;

    var elasticSearchUrl = $.getEnv( "elasticSearchUrl" );

    var headers = { "Content-Type": "application/json;charset=utf-8" };
    var elasticSearchUser = $.getEnv( "elasticSearchUser" );
    var elasticSearchPass = $.getEnv( "elasticSearchPass" );
    if (elasticSearchUser && elasticSearchPass) {
      var auth = Base64.encode( elasticSearchUser + ":" + elasticSearchPass );
      var basicAuth = "Basic " + auth;
      headers[ "Authorization" ] = basicAuth;
    }
    var searchUrl = elasticSearchUrl + "/is1erp/allinone/_search";

    var sndTxt = JSON.stringify( q );
    var s = HttpUtils.postRaw( searchUrl, sndTxt, headers );
    var result = JSON.parse( s );


    var elasticSearchUrl = $.getEnv( "elasticSearchUrl" );

    var headers = { "Content-Type": "application/json;charset=utf-8" };
    var elasticSearchUser = $.getEnv( "elasticSearchUser" );
    var elasticSearchPass = $.getEnv( "elasticSearchPass" );
    if (elasticSearchUser && elasticSearchPass) {
      var auth = Base64.encode( elasticSearchUser + ":" + elasticSearchPass );
      var basicAuth = "Basic " + auth;
      headers[ "Authorization" ] = basicAuth;
    }
    var searchUrl = elasticSearchUrl + "/owl_shop/_search";

    var sndTxt = JSON.stringify( q );
    $.log("export.jsx")
    $.log(sndTxt)

    var s = HttpUtils.postRaw( searchUrl, sndTxt, headers );
    var result = JSON.parse( s );
    var total = result.hits.total;

    var taskInfo = owl_shopService.getExportTaskInfo( taskInfoId );
    taskInfo.total = total;
    taskInfo.lastTime = new Date().getTime();
    taskInfo.processState = "processing";
    taskInfo.msg = "获取导出总数成功......";
    taskInfo.percent = "20";

  owl_shopService.updateExportTaskInfo( taskInfoId, taskInfo );

    q.size = total;

    var sndTxt = JSON.stringify( q );
    var s = HttpUtils.postRaw( searchUrl, sndTxt, headers );
    var result = JSON.parse( s );

    var hits = result.hits.hits;
    var objs = hits.map( function (hit){
      return hit._source
    } );

    var meta = spec[ "#meta" ];

    var rows = [];
    var row = [];

    var groupings = [];

    var mainFields = [];
    var subFields = [];

    var exConfig = null;
    if (meta.export) {
      meta.export.forEach(function(config){
        if(config.key == exportKey){
          exConfig = config;
        }
      });
      if (exConfig && exConfig.fields) {
        var fields = getMainAndSubFields(exConfig);
        mainFields = fields[0];
        subFields = fields[1];

        if(mainFields.length>0){
          row.push(exConfig.mainTitleFormat);
          mainFields.forEach( function (f){
            row.push( "s"+f.fieldLabel );
          } );
          rows.push(row);
        }
        else{
          //写入子记录的title一次
          row.push(exConfig.subTitleFormat);
          subFields.forEach( function (spec){
            row.push( "s" + spec.fieldLabel ); //子记录title
          } );
          rows.push(row);
        }

        var subTitleInterval = exConfig.subTitleInterval || 9999999;
        objs.forEach( function (obj,objIdx){
          if(mainFields.length>0){
            var row = [];
            row.push(exConfig.mainRecordFormat);
            mainFields.forEach( function (f){
              if(!f.key){
                row.push('null');
              }
              else{

                var value = owl_shopService.getValue( f.key, obj );
                $.log("getValue:" + f.key+":" +value);
                value = normalizeValue(value,f);
                row.push( value );
              }

            } );
            rows.push( row );
          }
          //写入子item的title
          if (subFields.length>0) {
            var row = [];
            var grouping = [];
            if(mainFields.length>0 && (objIdx % subTitleInterval)==0){
              //当有主记录的时候才写入子记录的Title
              row.push(exConfig.subTitleFormat);
              subFields.forEach( function (spec){
                row.push( "s" +spec.fieldLabel ); //子记录title
              } );
              rows.push( row );
              grouping[ 0 ] = rows.length - 1;
            }
            var items = obj[exConfig.items.name];
            items && items.forEach && items.forEach( function (item){
              var row = [];
              row.push(exConfig.subRecordFormat);
              subFields.forEach( function (spec){
                if(spec.isItemField){
                  var value = item[ spec.origKey ];
                  value = normalizeValue(value,spec);
                  row.push( value );
                }
                else{
                  if(spec.key){
                    var value = owl_shopService.getValue( spec.key, obj );
                    value = normalizeValue(value,spec);
                    row.push(value);
                  }
                  else{
                    row.push("")
                  }

                }
              } );
              rows.push( row );
            } );
            if(mainFields.length>0){
              grouping[ 1 ] = rows.length - 1;
              groupings.push( grouping );
            }
          }
        } );
      }

      var taskInfo = owl_shopService.getExportTaskInfo( taskInfoId );
      taskInfo.processState = "success";
      taskInfo.percent = 70;
      taskInfo.lastTime = new Date().getTime();
      taskInfo.msg = "获取数据记录完成";

      var fileId = Excel.createExcel( rows, groupings, "export" );
      var taskInfo = owl_shopService.getExportTaskInfo( taskInfoId );
      taskInfo.processState = "success";
      taskInfo.percent = 100;
      taskInfo.fileId = fileId;
      taskInfo.lastTime = new Date().getTime();
      taskInfo.msg = "生成Excel文件成功";
    owl_shopService.updateExportTaskInfo(taskInfoId, taskInfo );
    }
  }
)();











