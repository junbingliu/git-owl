//#import Util.js
//#import login.js
//#import session.js
//#import HttpUtil.js
//#import $owl_u:services/modelService.jsx


var spec = {"id":"string(12),tab:01,disabled:true;用户Id","name":"string(16),tab:02,searchable:true;用户名字","loginId":"string(16),tab:02,searchable:true,unique:true;登录Id","passwordhash":"password,tab:03,searchable:false,hidden:true;密码","random":"string(64),tab:03,searchable:false,hidden:true;密码","isEnable":"bool,tab:04,searchable:true,hidden:false;是否有效","mobile":"string(16),inputType:mobile,tab:03,searchable:true,unique:true;手机","mobile_verified":"bool,tab:03,searchable:true;手机是否已经验证","icon":"fileId,tab:04;头像","email":"string(16),tab:05,searchable:true;邮件","email_verified":"bool,tab:06,searchable:true;邮箱是否已验证","qq":"string(16),tab:06,searchable:true;qq号","qq_openId":"string(16),tab:06,searchable:true;qq openId","qq_icon":"url,tab:06,searchable:true;qq 头像","wechat":"url,tab:06,searchable:true;微信号","wechat_openId":"string(16),tab:10;微信 openId","wechat_icon":"string(16),tab:10;微信头像","isFake":"bool,tab:11,hidden:true,searchable:true;是否马甲","_t":"u","#meta":{"rem":"用户","parent":["platform"],"visitType":["platform"],"projectName":"用户","export":[{"label":"导出完整","mainTitleFormat":{"background":"#474747","color":"#cccccc"},"subTitleFormat":{"background":"#777777","color":"#ffffff"},"subRecordFormat":{"background":"#ffffff","color":"#000000"},"mainRecordFormat":{"background":"#555555","color":"#FFFFFF"},"key":"completeDoc","fields":["*"]}]}};

var backendUserId = LoginService.getBackEndLoginUserId();
var visitType = SessionService.getSessionValue( "visitType", request );
if (visitType) {
  visitType = JSON.parse( visitType );
}

var shopId = visitType.shop;
var warehouseId = visitType.warehouse;
m=shopId;
//为了显示数据，临时加上这个判断，现在很多数据都搜索不出来
if(!m){
  m = SessionService.getSessionValue("_loginMerId",request);
}

//判断是subplatform,还是shop,还是platform
var params = JSON.parse($body);
var id = params.id;
var msg = '';
owl_uService.del(id);
var ret = {
    state: msg ? 'err' : 'ok',
    msg: msg
}
out.print(JSON.stringify(ret));