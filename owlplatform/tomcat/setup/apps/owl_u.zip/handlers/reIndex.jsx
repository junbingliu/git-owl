//#import Util.js
//#import login.js
//#import session.js
//#import HttpUtil.js
//#import $owl_u:services/modelService.jsx

var spec = {"id":"string(12),tab:01,disabled:true;用户Id","name":"string(16),tab:02,searchable:true;用户名字","loginId":"string(16),tab:02,searchable:true,unique:true;登录Id","passwordhash":"password,tab:03,searchable:false,hidden:true;密码","random":"string(64),tab:03,searchable:false,hidden:true;密码","isEnable":"bool,tab:04,searchable:true,hidden:false;是否有效","mobile":"string(16),inputType:mobile,tab:03,searchable:true,unique:true;手机","mobile_verified":"bool,tab:03,searchable:true;手机是否已经验证","icon":"fileId,tab:04;头像","email":"string(16),tab:05,searchable:true;邮件","email_verified":"bool,tab:06,searchable:true;邮箱是否已验证","qq":"string(16),tab:06,searchable:true;qq号","qq_openId":"string(16),tab:06,searchable:true;qq openId","qq_icon":"url,tab:06,searchable:true;qq 头像","wechat":"url,tab:06,searchable:true;微信号","wechat_openId":"string(16),tab:10;微信 openId","wechat_icon":"string(16),tab:10;微信头像","isFake":"bool,tab:11,hidden:true,searchable:true;是否马甲","_t":"u","#meta":{"rem":"用户","parent":["platform"],"visitType":["platform"],"projectName":"用户","export":[{"label":"导出完整","mainTitleFormat":{"background":"#474747","color":"#cccccc"},"subTitleFormat":{"background":"#777777","color":"#ffffff"},"subRecordFormat":{"background":"#ffffff","color":"#000000"},"mainRecordFormat":{"background":"#555555","color":"#FFFFFF"},"key":"completeDoc","fields":["*"]}]}};

var backendUserId = LoginService.getBackEndLoginUserId();
if (!backendUserId) {
    out.print("请登录后再操作");
} else {
    var id = $.params.id;
    if (id) {
        var obj = owl_uService.get(id);
        owl_uService.index(obj);
        out.print(id + ":重建索引成功");
    } else {
        var start = $.params.start;
        var limit = $.params.limit;
        if (start != null && limit != null) {
            var listName = owl_uService.getAllListName();
            var list = owl_uService.getList(listName, start, limit);
            for (var i = 0; i < list.length; i++) {
                try {
                    owl_uService.index(list[i]);
                } catch (e) {
                    try {
                        out.print(list[i].id + ",重建索引失败，异常信息:" + JSON.stringify(e) + "<br>");
                    } catch (e1) {
                        out.print(list[i].id + ",重建索引失败，异常信息:" + e1 + "<br>");
                    }
                }
            }
            out.print(spec["_t"] + "重建索引成功:"+list.length);
        }else{
            try {
            owl_uService.reindexAll();
            } catch (e) {
                out.print("重建索引失败，异常信息:" + e + "<br>");
            }
            /*var list = owl_uService.getList(owl_uService.getAllListName(), 0, -1);
            list.forEach(function (value) {
                try{
                    owl_uService.index(value);
                }catch(e){
                    try {
                        out.print(value.id + ",重建索引失败，异常信息:" + JSON.stringify(e)+"<br>");
                    } catch (e1) {
                        out.print(value.id + ",重建索引失败，异常信息:" + e1+"<br>");
                    }
                }
            });*/
            out.print(spec["_t"] + "重建索引成功:");
        }
    }
}