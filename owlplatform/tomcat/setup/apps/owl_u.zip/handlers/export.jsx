//#import Util.js
//#import login.js
//#import base64.js
//#import HttpUtil.js
//#import session.js
//#import user.js
//#import $owl_u:services/modelService.jsx
function trim(s){
  if(s){
    return s.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '');
  }
  return ""
}

var spec = {"id":"string(12),tab:01,disabled:true;用户Id","name":"string(16),tab:02,searchable:true;用户名字","loginId":"string(16),tab:02,searchable:true,unique:true;登录Id","passwordhash":"password,tab:03,searchable:false,hidden:true;密码","random":"string(64),tab:03,searchable:false,hidden:true;密码","isEnable":"bool,tab:04,searchable:true,hidden:false;是否有效","mobile":"string(16),inputType:mobile,tab:03,searchable:true,unique:true;手机","mobile_verified":"bool,tab:03,searchable:true;手机是否已经验证","icon":"fileId,tab:04;头像","email":"string(16),tab:05,searchable:true;邮件","email_verified":"bool,tab:06,searchable:true;邮箱是否已验证","qq":"string(16),tab:06,searchable:true;qq号","qq_openId":"string(16),tab:06,searchable:true;qq openId","qq_icon":"url,tab:06,searchable:true;qq 头像","wechat":"url,tab:06,searchable:true;微信号","wechat_openId":"string(16),tab:10;微信 openId","wechat_icon":"string(16),tab:10;微信头像","isFake":"bool,tab:11,hidden:true,searchable:true;是否马甲","_t":"u","#meta":{"rem":"用户","parent":["platform"],"visitType":["platform"],"projectName":"用户","export":[{"label":"导出完整","mainTitleFormat":{"background":"#474747","color":"#cccccc"},"subTitleFormat":{"background":"#777777","color":"#ffffff"},"subRecordFormat":{"background":"#ffffff","color":"#000000"},"mainRecordFormat":{"background":"#555555","color":"#FFFFFF"},"key":"completeDoc","fields":["*"]}]}};

var backendUserId = LoginService.getBackEndLoginUserId();
var user = UserService.getUser( backendUserId );
var visitType = SessionService.getSessionValue( "visitType", request );
if (visitType) {
  visitType = JSON.parse( visitType );
}

var shopId = visitType.shop;
var warehouseId = visitType.warehouse;
m=shopId;
//为了显示数据，临时加上这个判断，现在很多数据都搜索不出来
if(!m){
  m = SessionService.getSessionValue("_loginMerId",request);
}



var now = new Date().getTime();
var u = {
  id: user.id,
  realName: user.realName,
  nickName: user.nickName
}

var visitType = SessionService.getSessionValue( "visitType", request );
if (visitType) {
  visitType = JSON.parse( visitType );
}

var shopId = visitType.shop;
var warehouseId = visitType.warehouse;


//判断是subplatform,还是shop,还是platform
var params = JSON.parse($body);
var searchArgs = params.searchArgs;
var keyword = searchArgs.keyword;
var pageSize = params.pageSize;
var exportKey = params.exportKey;

var env = {
  now: new Date().getTime(),
  loginId: backendUserId,
  loginUser: u,
  shopId:shopId,
  exportKey:exportKey,
  warehouseId:warehouseId
}


function getKeywordQuery(){
  if(keyword && trim(keyword).length>0){
    return "\"" + trim(keyword) + "\""
  }
  else{
    return "*"
  }
}

function getFilters(){
  delete searchArgs.keyword;
  var filters = [];
  for(var k in searchArgs){
    var v = searchArgs[k];
    if(typeof(v)=='object' && Array.isArray(v)){
      var range={}
      range[k] = {
        'gte':v[0],
        'lte':v[1]
      }
      filters.push({range:range});
    }
    else{
      var term = {};
      term[k+".keyword"] = trim('' + v)
      filters.push({term:term})
    }

  }
  return filters;
}

var filters = getFilters();

if(m!=='0'){
    filters = filters.concat([
        {"term": { "_m.keyword": m }},
        {"term":{"_t":spec["_t"]}}
    ]);
}
else{
    filters = filters.concat([
        {"term":{"_t":spec["_t"]}}
    ]);
}


var query = {
  "query": {
    "bool": {
      "must": {
        "query_string": {
          "query":getKeywordQuery()
        }
      },
      "must_not": {
        "match": {
          "del": "T"
        }
      },
      "filter": filters
    }
  },
  "from" : 0, "size" : 1,
  sort:[{_createTime:{order:"desc"}}]
}


var taskInfoId = owl_uService.addExportTask(query,env);

var ret = {
  state:'ok',
  taskInfoId : taskInfoId
}

out.print(JSON.stringify(ret));





