//#import Util.js

var repository_version = "${repository.version}"
var buildTime = "2018-09-03 08:04 PM"

var pageData = {
    repository_version: repository_version,
    buildTime: buildTime,
}

var html = $.runArtTemplate(appId,appMd5,"about.html",pageData);
out.print(html);