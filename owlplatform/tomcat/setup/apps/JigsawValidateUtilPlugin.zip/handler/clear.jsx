//#import Util.js
//#import login.js
//#import file.js
//#import base64.js
//#import $JigsawValidateUtilPlugin:services/GlobalSysArgsService.jsx


GlobalSysArgsService.saveArgs({jigsawBgImages :[]});

