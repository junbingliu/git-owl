//#import Util.js
//#import user.js
//#import login.js
//#import session.js
//#import DigestUtil.js
//#import json2.js
//#import address.js
//#import search.js
//#import NoticeTrigger.js
//#import DateUtil.js
//#import pageService.js
//#import sysArgument.js
//#import encryptUtil.js
//#import doT.min.js

(function () {
    var ret = {
        code:'1',
        msg:''
    }

    //校验滑块位移是否正确-------begin
    var isCheck = SessionService.getSessionValue("JigsawValidateUtilCheckMove", request);
    if(!isCheck||isCheck!="true"){
        ret.msg = "未通过图片验证码验证";
        out.print(JSON.stringify(ret));
        return;
    }
    //校验滑块位移是否正确-------end

    var loginKey = $.params.lk;

    if(!loginKey){
        ret.msg = "用户名或手机号码为空";
        out.print(JSON.stringify(ret));
        return;
    }

    var user = LoginApi.IsoneModulesEngine.memberService.getUserByKey(loginKey);
    if (!user ||user=='') {
        ret.msg = "用户不存在";
        out.print(JSON.stringify(ret));
        return;
    }

    var template = $.getProgram(appMd5, "reCheck.html");
    var pageFn = doT.template(template);
    out.print(pageFn());
})();

