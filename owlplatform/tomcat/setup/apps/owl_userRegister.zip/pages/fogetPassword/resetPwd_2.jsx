//#import Util.js
//#import user.js
//#import login.js
//#import session.js
//#import DigestUtil.js
//#import json2.js
//#import address.js
//#import search.js
//#import NoticeTrigger.js
//#import DateUtil.js
//#import pageService.js
//#import sysArgument.js
//#import encryptUtil.js
//#import doT.min.js

(function () {
    var ret = {
        code:'1',
        msg:''
    }

    //校验滑块位移是否正确-------begin
    var isCheck = SessionService.getSessionValue("JigsawValidateUtilCheckMove", request);
    if(!isCheck||isCheck!="true"){
        ret.msg = "未通过图片验证码验证";
        out.print(JSON.stringify(ret));
        return;
    }
    //校验滑块位移是否正确-------end

    var loginKey = $.params.lk;

    if(!loginKey){
        ret.msg = "用户名或手机号码为空";
        out.print(JSON.stringify(ret));
        return;
    }
    
    var user = LoginApi.IsoneModulesEngine.memberService.getUserByKey(loginKey);
    if (!user ||user=='') {
        ret.msg = "用户不存在";
        out.print(JSON.stringify(ret));
        return;
    }
    var mobileCaptchaSessionName = "forgetPasswordMobileCaptchaObj";
    var validTime = 5;//分钟，短信验证码有效时间
    var mobileCaptchaObj = SessionService.getSessionValue(mobileCaptchaSessionName, request);
    if (!mobileCaptchaObj) {
        ret.msg = "phone_validate_code_empty";
        out.print(JSON.stringify(ret));
        return;
    }
    mobileCaptchaObj = JSON.parse(mobileCaptchaObj);

    var timeOut = validTime * 60 * 1000;
    var currTime = new Date().getTime();
    if (currTime - mobileCaptchaObj["lastTime"] >= timeOut) {
        //超时
        ret.msg = "phone_validate_code_overdue";
        out.print(JSON.stringify(ret));
        return;
    }

    if (mobileCaptchaObj["captcha"] != mobileValidateCode) {
        //验证码错误
        ret.msg = "phone_validate_code_error";
        out.print(JSON.stringify(ret));
        return;
    }

    if (mobileCaptchaObj["mobile"] != mobilePhone) {
        //注册手机和短信验证手机不一致
        ret.msg = "mobilePhone_error";
        out.print(JSON.stringify(ret));
        return;
    }

    var identityObj={
        lastTime:new Date().getTime(),
        mobilePhone:mobilePhone,
        isCheck:"true"
    }

    SessionService.addSessionValue("checkIdentityToResetPwd", JSON.stringify(identityObj), request, response);

    var template = $.getProgram(appMd5, "reCheck.html");
    var pageFn = doT.template(template);
    out.print(pageFn());
})();

