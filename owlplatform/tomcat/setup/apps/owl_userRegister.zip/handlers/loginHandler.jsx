//#import Util.js
//#import user.js
//#import login.js
//#import session.js
//#import sysArgument.js
//#import encryptUtil.js

(function () {
    try {
        var errorCode = "";
        var ret = {
            state: false,
            errorCode: errorCode
        }

        //校验滑块位移是否正确-------begin
        var isCheck = SessionService.getSessionValue("JigsawValidateUtilCheckMove", request);
        if(!isCheck || isCheck!='true'){
            ret.errorCode = "未通过图片验证码验证";
            out.print(JSON.stringify(ret));
            return;
        }
        //校验滑块位移是否正确-------end

        var loginKey = $.params.lk;    //登录Id，可以是loginId,mobilePhone
        var password = $.params.pa;  //登录密码

        if (!loginKey) {
            errorCode = "用户名为空";
        }  else if (!password) {
            errorCode = "密码为空";
        }  else {
            var resultCode = {
                100: "success",
                101: "data_error",
                102: "data_error",
                103: "用户名或密码错误",
                104: "用户名或密码错误",
                105: "not_enabled",
                106: "password_null"
            };

            var user = LoginApi.IsoneModulesEngine.memberService.getUserByKey(loginKey);
            if (!user ||user=='') {
                ret["state"] = false;
                ret.errorCode =  resultCode["103"];
                out.print(JSON.stringify(ret));
                return;
            }
            var passwordhash = user.optString("passwordhash");
            if(!passwordhash || passwordhash == ""){
                ret["state"] = false;
                ret.errorCode =  resultCode["106"];
                out.print(JSON.stringify(ret));
                return;
            }

            var result = LoginApi.LoginUtil.loginByKey(loginKey, password, LoginApi.LoginUtil.TARGET_MEMBER);
            if (result == 100) {
                //100 ==  IUserService.LOGIN_SUCCESSFUL
                var userId = user.optString("id");
                LoginApi.LoginSessionUtils.loginFrontend(request, response, userId);
                //记录最后登录时间
                var isOK = LoginApi.UserUtil.setLastLoginLog(user, request);
                if (isOK) {
                    LoginApi.IsoneModulesEngine.adminService.updateUser(user, userId);
                }
                ret["state"] = true;
                SessionService.removeSessionValue('JigsawValidateUtilCheckMove');//调用接口成功后一定要remove掉才安全
            } else {
                ret["state"] = false;
            }
            errorCode = resultCode[result];
        }
        ret.errorCode = errorCode;
        out.print(JSON.stringify(ret));
    } catch (e) {
        var ret = {
            state: false,
            errorCode: "system_error"
        }
        out.print(JSON.stringify(ret));
        $.log(e);
    }
})();