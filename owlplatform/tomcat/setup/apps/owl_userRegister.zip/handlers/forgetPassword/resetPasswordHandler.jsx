//#import Util.js
//#import user.js
//#import login.js
//#import session.js
//#import DigestUtil.js
//#import json2.js
//#import address.js
//#import search.js
//#import NoticeTrigger.js
//#import DateUtil.js
//#import pageService.js
//#import sysArgument.js
//#import encryptUtil.js

(function () {
    var ret = {}

    var password = $.params.pa;  //新密码

    if(!password || password==''){
        ret.errorCode = "密码为空";
        out.print(JSON.stringify(ret));
        return;
    }

    var identityObj = SessionService.getSessionValue("checkIdentityToResetPwd", request);
    identityObj = JSON.parse(identityObj);

    if(!identityObj || identityObj=={}){
        ret.errorCode = "未通过身份验证";
        out.print(JSON.stringify(ret));
        return;
    }

    var validTime = 5;//分钟，session值过期时间
    var timeOut = validTime * 60 * 1000;
    var currTime = new Date().getTime();
    if (currTime - identityObj["lastTime"] >= timeOut) {
        //session值过期
        ret.errorCode = "session_overdue";
        out.print(JSON.stringify(ret));
        return;
    }

    var mobilePhone =identityObj['mobilePhone'];
    var isCheck = identityObj['isCheck'];

    if(!isCheck || isCheck!='true'){
        ret.errorCode = "未通过身份验证";
        out.print(JSON.stringify(ret));
        return;
    }

    var jUser = LoginApi.IsoneModulesEngine.memberService.getUserByKey(mobilePhone);

    if(!jUser ||jUser==''){
        ret.errorCode = "手机号码不存在";
        out.print(JSON.stringify(ret));
        return;
    }

    var ran = Math.random() + "";
    var passran = password + ran;
    var passwordsha = DigestUtil.digestString(passran, "SHA");

    jUser["passwordhash"] = passwordsha;
    jUser["random"] = ran;

    var javaUserJson = $.toJavaJSONObject(jUser);
    var userId = UserApi.IsoneModulesEngine.memberService.addUser(javaUserJson, null);

    var User = UserService.getUser(userId);

    if(User!=''||User!='null'){
        ret.code = 'ok';
        ret.errorCode = "";
        SessionService.removeSessionValue('checkIdentityToResetPwd');
        out.print(JSON.stringify(ret));
    }else {
        ret.errorCode = "重置密码失败";
        out.print(JSON.stringify(ret));
    }

})();

